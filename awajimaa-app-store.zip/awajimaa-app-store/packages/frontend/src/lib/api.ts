// API base — points to the App Store API server.
// In development, Vite's dev server proxy forwards /store/* to localhost:4000.
// In production, set VITE_API_URL to your deployed API server URL.
const API_URL = import.meta.env.VITE_API_URL ?? "";
const API_BASE = `${API_URL}/store`;

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `HTTP ${res.status}`);
  }
  if (res.status === 204) return undefined as unknown as T;
  return res.json() as Promise<T>;
}
