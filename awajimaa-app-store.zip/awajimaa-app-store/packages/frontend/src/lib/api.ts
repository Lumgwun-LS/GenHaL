// In development, Vite proxies /store/* to the local API server (localhost:4000).
// In production, set VITE_API_URL to your deployed API URL; leave it empty to use a same-origin proxy.
const API_BASE = `${import.meta.env.VITE_API_URL ?? ""}/store`;

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `HTTP ${res.status}`);
  }
  if (res.status === 204) return undefined as unknown as T;
  return res.json() as Promise<T>;
}
