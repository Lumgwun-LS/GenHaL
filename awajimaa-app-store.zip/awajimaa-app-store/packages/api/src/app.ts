import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { clerkMiddleware } from "@clerk/express";
import { logger } from "./lib/logger.js";
import storeRouter from "./routes/store.js";

const app: Express = express();

// ─── CORS ─────────────────────────────────────────────────────────────────────
const allowedOrigins = (process.env.ALLOWED_ORIGINS ?? "").split(",").map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes("*") || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS: origin ${origin} not allowed`));
    }
  },
  credentials: true,
}));

// ─── Logging ──────────────────────────────────────────────────────────────────
app.use(pinoHttp({ logger }));

// ─── Clerk auth middleware ─────────────────────────────────────────────────────
app.use(clerkMiddleware());

// ─── Body parsing ─────────────────────────────────────────────────────────────
// Paystack webhooks need raw body for HMAC verification — mount raw before json
app.use("/store/webhooks", express.raw({ type: "*/*" }));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

// ─── Health check ─────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "awajimaa-app-store-api", ts: new Date().toISOString() });
});

// ─── Store routes — mounted at /store ────────────────────────────────────────
app.use("/store", storeRouter);

// ─── 404 handler ─────────────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: "Not found" });
});

// ─── Error handler ────────────────────────────────────────────────────────────
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  logger.error({ err }, "Unhandled error");
  res.status(500).json({ error: "Internal server error" });
});

export default app;
