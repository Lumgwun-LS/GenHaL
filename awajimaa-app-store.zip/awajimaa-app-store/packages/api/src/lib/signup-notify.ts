import { sendEmail } from "./mailer.js";
import { logger } from "./logger.js";

const ADMIN_EMAIL = process.env.ADMIN_NOTIFY_EMAIL ?? "Lumgwunsolutions@gmail.com";

export type SignupPlatform = "app-store" | "app-store-user";

interface SignupInfo {
  platform: SignupPlatform;
  name: string;
  email: string;
  phone?: string | null;
  country?: string | null;
}

export function notifyAdminSignup(info: SignupInfo): void {
  void (async () => {
    try {
      const platformLabel: Record<SignupPlatform, string> = {
        "app-store":      "Awajimaa App Store (Developer)",
        "app-store-user": "Awajimaa App Store (User)",
      };
      const label = platformLabel[info.platform];
      const now = new Date().toLocaleString("en-NG", {
        timeZone: "Africa/Lagos",
        dateStyle: "full",
        timeStyle: "short",
      });
      const rows = [
        ["Platform", label],
        ["Name", info.name],
        ["Email", info.email],
        ...(info.phone ? [["Phone", info.phone]] : []),
        ...(info.country ? [["Country", info.country]] : []),
        ["Signed up", now],
      ] as [string, string][];
      const tableRows = rows.map(([k, v]) => `
        <tr>
          <td style="padding:8px 12px;font-weight:600;color:#555;white-space:nowrap;border-bottom:1px solid #f0f0f0;">${k}</td>
          <td style="padding:8px 12px;color:#111;border-bottom:1px solid #f0f0f0;">${v}</td>
        </tr>`).join("");
      const html = `<!DOCTYPE html><html><head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:Inter,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:32px 0;">
    <tr><td align="center">
      <table width="540" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);">
        <tr><td style="background:linear-gradient(135deg,#d32f2f 0%,#f9a825 100%);padding:28px 32px;">
          <p style="margin:0;font-size:22px;font-weight:700;color:#fff;">🎉 New Sign-up on Awajimaa</p>
          <p style="margin:6px 0 0;font-size:13px;color:rgba(255,255,255,0.85);">${label}</p>
        </td></tr>
        <tr><td style="padding:28px 32px 12px;">
          <p style="margin:0 0 16px;font-size:14px;color:#444;">A new user just joined <strong>Awajimaa</strong>:</p>
          <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #f0f0f0;border-radius:8px;overflow:hidden;">${tableRows}</table>
        </td></tr>
        <tr><td style="padding:20px 32px 28px;">
          <p style="margin:0;font-size:12px;color:#999;">Automated notification from the Awajimaa App Store.</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
      await sendEmail({
        to: ADMIN_EMAIL,
        subject: `New sign-up: ${info.name} — ${label}`,
        html,
        text: `New sign-up on ${label}\n\nName: ${info.name}\nEmail: ${info.email}${info.country ? `\nCountry: ${info.country}` : ""}\nSigned up: ${now}`,
      });
    } catch (err) {
      logger.warn({ err }, "[signup-notify] Failed to send admin signup alert");
    }
  })();
}
