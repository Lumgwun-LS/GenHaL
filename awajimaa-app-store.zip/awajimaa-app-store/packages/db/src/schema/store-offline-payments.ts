import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { storeAppsTable } from "./store-apps.js";
import { storeDeveloperAccountsTable } from "./store-developer-accounts.js";

export const storeOfflinePaymentsTable = pgTable("store_offline_payments", {
  id: serial("id").primaryKey(),
  appId: integer("app_id").notNull().references(() => storeAppsTable.id, { onDelete: "cascade" }),
  developerId: integer("developer_id").notNull().references(() => storeDeveloperAccountsTable.id, { onDelete: "cascade" }),
  proofUrl: text("proof_url").notNull(),
  proofNote: text("proof_note"),
  amountPaid: text("amount_paid"),
  bankReference: text("bank_reference"),
  status: text("status").notNull().default("submitted"),
  adminApprovedByClerkId: text("admin_approved_by_clerk_id"),
  adminApprovedAt: timestamp("admin_approved_at"),
  adminNote: text("admin_note"),
  superApprovedByClerkId: text("super_approved_by_clerk_id"),
  superApprovedAt: timestamp("super_approved_at"),
  superNote: text("super_note"),
  rejectedByClerkId: text("rejected_by_clerk_id"),
  rejectedAt: timestamp("rejected_at"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
