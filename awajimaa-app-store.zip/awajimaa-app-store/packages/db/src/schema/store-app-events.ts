import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { storeAppsTable } from "./store-apps.js";

export const storeAppEventsTable = pgTable("store_app_events", {
  id:           serial("id").primaryKey(),
  appId:        integer("app_id").notNull().references(() => storeAppsTable.id, { onDelete: "cascade" }),
  eventType:    text("event_type").notNull(),
  sessionId:    text("session_id"),
  clerkUserId:  text("clerk_user_id"),
  country:      text("country"),
  userAgent:    text("user_agent"),
  createdAt:    timestamp("created_at").notNull().defaultNow(),
});
