import { pgTable, text, serial, timestamp, integer, boolean, real, jsonb } from "drizzle-orm/pg-core";
import { storeDeveloperAccountsTable } from "./store-developer-accounts.js";

export const storeAppsTable = pgTable("store_apps", {
  id: serial("id").primaryKey(),
  developerId: integer("developer_id").notNull().references(() => storeDeveloperAccountsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  platform: text("platform").notNull().default("android"),
  iconUrl: text("icon_url").notNull(),
  screenshots: jsonb("screenshots").$type<string[]>().notNull().default([]),
  packageName: text("package_name").unique(),
  downloadUrl: text("download_url"),
  webUrl: text("web_url"),
  currentVersion: text("current_version"),
  // pending_payment | pending_review | approved | rejected
  status: text("status").notNull().default("pending_payment"),
  isFeatured: boolean("is_featured").notNull().default(false),
  rating: real("rating").notNull().default(0),
  ratingCount: integer("rating_count").notNull().default(0),
  totalDownloads: integer("total_downloads").notNull().default(0),
  // Publishing fee
  publishingFeePaid: boolean("publishing_fee_paid").notNull().default(false),
  publishingFeeGateway: text("publishing_fee_gateway"),
  publishingFeeRef: text("publishing_fee_ref"),
  publishingFeeAmountKobo: integer("publishing_fee_amount_kobo"),
  // AI review
  aiSummary: text("ai_summary"),
  aiCategory: text("ai_category"),
  aiPolicyFlags: text("ai_policy_flags"),
  aiReviewScore: real("ai_review_score"),
  aiReviewedAt: timestamp("ai_reviewed_at"),
  // Admin review
  reviewedByClerkId: text("reviewed_by_clerk_id"),
  reviewedAt: timestamp("reviewed_at"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
