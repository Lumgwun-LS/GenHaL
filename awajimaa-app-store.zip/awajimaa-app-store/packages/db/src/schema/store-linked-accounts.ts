import { pgTable, serial, integer, text, boolean, timestamp } from "drizzle-orm/pg-core";
import { storeDeveloperAccountsTable } from "./store-developer-accounts.js";

export const storeLinkedAccountsTable = pgTable("store_linked_accounts", {
  id: serial("id").primaryKey(),
  developerId: integer("developer_id")
    .notNull()
    .references(() => storeDeveloperAccountsTable.id, { onDelete: "cascade" }),
  platform: text("platform").notNull(),
  username: text("username"),
  displayName: text("display_name"),
  accessToken: text("access_token").notNull(),
  instanceUrl: text("instance_url"),
  avatarUrl: text("avatar_url"),
  verified: boolean("verified").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
