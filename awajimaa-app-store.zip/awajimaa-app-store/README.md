# Awajimaa App Store

Africa's premier app marketplace — built for African developers and users across all 54 countries.

## Architecture

```
packages/
├── db/        Drizzle ORM schema + migrations (PostgreSQL)
├── api/       Express API server (Clerk auth, Paystack, Interswitch)
└── frontend/  React + Vite frontend (Tailwind CSS, Shadcn UI)
```

## Prerequisites

- Node.js 20+
- pnpm 9+
- PostgreSQL database
- Clerk account (auth)
- Paystack account (payments)

## Setup

```bash
# 1. Install dependencies
pnpm install

# 2. Configure environment
cp .env.example .env
# Fill in all values in .env

# 3. Build the DB package
pnpm build:db

# 4. Apply database schema
pnpm db:push

# 5. Run the API server (port 4000 by default)
pnpm dev:api

# 6. Run the frontend (separate terminal, port 5173 by default)
pnpm dev:frontend
```

## Environment Variables

See `.env.example` for all required variables.

**Key variables:**
- `DATABASE_URL` — PostgreSQL connection string (same DB as Awa Biz Suite is fine; store tables are prefixed `store_*`)
- `CLERK_SECRET_KEY` / `CLERK_PUBLISHABLE_KEY` — same Clerk tenant as Awa Biz Suite
- `ADMIN_USER_IDS` — comma-separated Clerk user IDs for admin access
- `SUPER_ADMIN_EMAILS` — comma-separated emails for super admin (offline payment final approval)
- `VITE_API_URL` — URL of your deployed API server (e.g. `https://api.awajimaaappstore.com`)
- `VITE_CLERK_PUBLISHABLE_KEY` — same as `CLERK_PUBLISHABLE_KEY`

## Database

The store uses 11 dedicated tables, all prefixed `store_`:

- `store_apps` — app listings
- `store_developer_accounts` — registered developers
- `store_app_versions` — version history
- `store_app_reviews` — user reviews
- `store_app_events` — analytics events
- `store_app_repo_links` — linked git repos
- `store_linked_accounts` — developer platform PATs
- `store_app_update_requests` — app update submissions
- `store_user_signups` — first-time user tracking
- `store_offline_payments` — bank transfer payment proofs
- `store_relations` — Drizzle relation helpers

These tables can safely coexist in the same PostgreSQL instance as Awa Biz Suite.

## Deployment

### API Server
Deploy `packages/api` to any Node.js host (Railway, Render, Fly.io, VPS).

```bash
pnpm build:api
# Then run: node packages/api/dist/index.js
```

### Frontend
Deploy `packages/frontend` to any static host (Vercel, Netlify, Cloudflare Pages).

```bash
pnpm build:frontend
# Output is in packages/frontend/dist/
```

Set `VITE_API_URL` to your deployed API URL before building the frontend.

## Publishing Fee

The app publishing fee is ₦25,000 (configurable in `packages/api/src/routes/store.ts`).
Supported gateways: Paystack, Interswitch, Bank Transfer (offline, requires admin approval).

## Admin Access

- **Admin**: set `ADMIN_USER_IDS` to Clerk user IDs — full app review, developer management
- **Super Admin**: set `SUPER_ADMIN_EMAILS` to email addresses — can grant final offline payment approval

---

Built by [Awajimaa Technology / Lumgwun Solutions](https://awajimaa.com)
