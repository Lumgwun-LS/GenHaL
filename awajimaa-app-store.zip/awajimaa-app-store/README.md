# Awajimaa App Store

Standalone monorepo for the Awajimaa App Store — decoupled from the Awa Biz Suite.

## Structure

```
packages/
├── db/        Drizzle schema for all store_* tables
├── api/       Express API server (Clerk auth, Paystack, Stripe, AI review)
└── frontend/  React + Vite storefront
```

## Quick Start

```bash
cp .env.example .env      # fill in your values
pnpm install
pnpm db:push              # applies store_* schema to your DB (safe no-op if tables exist)
pnpm dev:api              # starts API on port 4000
pnpm dev:frontend         # starts frontend on port 5173
```

## Notes

- **Database**: shares the same Postgres instance as Awa Biz Suite — all tables are prefixed `store_*`.
- **Auth**: same Clerk tenant — developers and users log in with the same credentials.
- **AI review**: requires `OPENAI_API_KEY` (GPT-4o-mini).
- **Bank transfer details** in the offline payment modal are placeholders — replace before go-live.
